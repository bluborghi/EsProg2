struct node{
	char cont[81];
	char tipo;
};
